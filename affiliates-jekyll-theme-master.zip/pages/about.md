---
layout: page
title: About
permalink: "/about/"
image: assets/images/screenshot.png
---

This website is a demonstration to see **Affiliates Jekyll theme** in action. 

The theme is compatible with Github pages. This demo is created with Github Pages and hosted with Github. 

Everything is ready for your quick setup: Blog, Categories, About, Privacy Policy, Terms of Use, Contact form, Mailchimp

[Get it here](https://bootstrapstarter.com/jekyll-theme-memoirs/)

